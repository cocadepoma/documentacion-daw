export interface UserContact {
  email: string;
  name: string;
  country: string;
  zip: number;
  age: number;
  sex: string;
  text: string;
  gamer: boolean;
}
