export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDbr9CLaDPd75ULZode5FEgz6heB6xtJo8',
    authDomain: 'nasaimageday.firebaseapp.com',
    projectId: 'nasaimageday',
    storageBucket: 'nasaimageday.appspot.com',
    messagingSenderId: '61058484349',
    appId: '1:61058484349:web:df9396c9058d953a914914',
  },
};
