# WeatherAPP

1. Install node_modules:
~~~
$ npm install
~~~

2. Run the project (localhost:3000):
~~~
$ npm start
~~~


## Made by FRS
