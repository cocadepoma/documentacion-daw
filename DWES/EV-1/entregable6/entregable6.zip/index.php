
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>entregable6</title>
    <style>
        body {
            padding: 300px;
        }
    </style>
</head>
<body>

    <form action="calendario.php" method="post">

        <p>Introducir mes y año: </p>

        <label for="month">Mes: </label>
        <input type="text" name="month">
        <br><br>
        <label for="year">Año: </label>
        <input type="text" name="year">
        <br><br>
        <input type="submit" value="Enviar">

    </form>
</body>
</html>
