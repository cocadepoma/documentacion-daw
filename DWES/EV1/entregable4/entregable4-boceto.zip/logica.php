<?php

    /* ENTREGABLE 4 */

    /* Realizar una web que genere una contraseña aleatoria.
    ** La web me pedirá un número de dígitos para la contraseña (entre 8 y 12),
    ** si el número de dígitos no está entre ese rango o no se introducen números
    ** se volverá a la página de inicio. 
    ** La contraseña puede tener números, letras mayúsculas 
    ** y minúsculas así como símbolos (%&$.-: etc.). 
    ** Solo se permiten dos repeticiones no contiguas del mismo carácter.
    ** La contraseña se mostrará en la primera línea de la propia página del formulario. */

    // Caracteres que no se muestran correctamente en HTML  "¡²³¤€¼½¾‘’¥×¬»«öóíúüþ®éåäáßðø¶´¿çµñ©æ";
    // Caracteres que son problemáticos en el HTML  " \ < ' # & %"

    // IMPORTANTE Cambiar path al desplegar en otro PC
    function redireccionar(){ header('Location: http://localhost/entregable4'); }

    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@$^*()-_+[]{};:,.>/?";
    $chars.= '"';
    $cnt = 0;   
    $password = '';
    
    if(isset($_POST['numero']) && $_POST['numero'] != '') {
        
        $longitud_pwd = $_POST['numero'];
        
        if(is_numeric($longitud_pwd) && $longitud_pwd >= 8 && $longitud_pwd <=12) {

            do {
                // Generar un num. aleatorio desde 0 hasta la longitud de $chars-1
                $posicionString = rand ( 0 , strlen($chars)-1 );

                // Cuando el $password es una cadena vacía => guardar el char
                if($cnt == 0) {

                    $password.= $chars{$posicionString};
                    $cnt++;

                } else {
                    /* Si las 2 últimas posiciones del password son iguales al $chars{$posicionString}
                    ** salir y generar otro, en caso contrario concatenar con el $password */
                    if($chars{$posicionString} == $password{strlen($password)-1} && $chars{$posicionString} == $password{strlen($password)-2}){
                        return;
                    } else {
                        $password.= $chars{$posicionString};
                        $cnt++;
                    }
                }
            }while($cnt < $longitud_pwd);
            
        } else {
            redireccionar();
        }

    } else {
        redireccionar();
    }

    if($cnt == $_POST['numero']) {
        header('Location: http://localhost/trabajos/DAW/entregable4?password='.$password);
    }

?>