<?php
   
        $connectionDB = connectDB("ferreteria");
    
        if($connectionDB) {
    
            $query = "SELECT ccif, cnombre, capellidos, cdireccion FROM clientes";
        
            if($resultado = $connectionDB->query($query)) {
    
                echo "<table><thead><tr><td>CIF</td><td>Nombre</td><td>Apellidos</td><td>Dirección</td></tr></thead><tbody>";
                
                while($row = $resultado->fetch_assoc()){
                    echo "<tr><td>" . $row['ccif'] . "</td>";
                    echo "<td>" . $row['cnombre'] . "</td>";
                    echo "<td>" . $row['capellidos'] . "</td>";
                    echo "<td>" . $row['cdireccion'] . "</td></tr>";
                }
    
                echo "</tbody></table>";
            }
    
            closeDB($connectionDB);
        }

?>