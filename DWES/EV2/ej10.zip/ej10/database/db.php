<?php

    function connectDB($db_name, $url = "localhost", $user = "root", $password = "") {

        $mysqli = new mysqli( $url, $user, $password, $db_name);

        if($mysqli) {
            $mysqli->set_charset('utf8');
            return $mysqli;
        }

    }

    function closeDB($mysqli){

        if($mysqli) {
            $mysqli->close();
        }
    }



?>