

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    table {
        border-collapse: collapse;
    }
    thead {
        text-align: center;
        background-color: #bbbcfd;
        font-weight: bold;
    }
    table td {
        padding: 5px;
        border: 1px solid black;
    }
    .btn {
        padding: 5px;
        cursor: pointer;
        margin-bottom: 20px;
        text-transform: uppercase;
        font-size: 20px;
        font-weight: bold;
    }
    .connect {
        background-color: #c0f972;
    }
    .disconnect {
        background-color: #f93939;
    }
</style>
<body>


    <form action="index.php" method="POST">

        <?php
            if(!isset($_POST['connect'])) {
                echo "<input class='btn connect' type='submit' name='connect' value='ConnectDB'>";
            }
        ?>

        <?php
            if(isset($_POST['connect'])) {
                echo "<input class='btn disconnect' type='submit' name='close' value='CloseDB'>";
            }
        ?>
    </form>

    <?php
        
        if(isset($_POST['connect'])) {
            require_once('./database/db.php');
            require_once('./database/clients.php');
        }

    ?>

</body>
</html>