<?php

    // Tratar warnings como errores
    mysqli_report(MYSQLI_REPORT_STRICT);

    try {
        $conn = new mysqli('localhost', 'root', '', 'ferreteria');
    } catch (Exception $e) {
        echo "Error al conectar con la BBDD, inténtelo de nuevo pasados unos minutos";
    }
    
?>