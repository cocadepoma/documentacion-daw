<?php

    // Conexción BBDD
    require('./db.php');
    
    $surname = $_POST['surname'];
    $surname_like = "%$surname%";

    // Si se ha establecido la conexión, seguir con la consulta
    if(isset($conn) && $conn) {
        
        try {
    
            // Crear consulta
            $sql = "SELECT ccif, cnombre, capellidos, cdireccion FROM clientes WHERE capellidos = ? OR capellidos LIKE ?";
            
            // Abrir Statement
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $surname, $surname_like);
    
            // Ejecutar Statement
            $stmt->execute();
    
            // Guardar resultados
            $result = $stmt->get_result();
            

            if($result->num_rows > 0) {

                echo "<p class='white'>Mostrando resultados con el apellido <span class='name'>$surname</span> ...</p>";
                echo "<table><thead><tr><td>CIF</td><td>Nombre</td><td>Apellidos</td><td>Dirección</td></tr></thead><tbody>";
        
                while($row = $result->fetch_assoc()){
                    echo "<tr><td>" . $row['ccif'] . "</td>";
                    echo "<td>" . $row['cnombre'] . "</td>";
                    echo "<td>" . $row['capellidos'] . "</td>";
                    echo "<td>" . $row['cdireccion'] . "</td></tr>";
                }
        
                echo "</tbody></table>";
            
            } else {
                echo "<h3 class='white'><span class='no_bold'>No se han encontrado apellidos con </span class='no_bold'> $surname</h3>";
            }

            // Cerrar Statement
            $stmt->close();
    
            // Desconectar BBDD
            $conn->close();
    
        } catch (\Exception $e){
            echo "Ha habido un error con la petición, inténtelo de nuevo más tarde";
        }
    }

?>