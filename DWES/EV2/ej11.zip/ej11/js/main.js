$(document).ready(() => {

    // SUBMIT
    $('form').submit((e) => {

        e.preventDefault();
        if (($('#surname').val()).length === 0) {
            $('.error').show();
        } else {
            $('.error').hide();
        }
        requestSurname($(this).val());

    });

    // KEYPRESS
    $('#surname').bind('keyup', function() {
        requestSurname($(this).val());
    });

    // REQUEST DATABASE
    function requestSurname(surname) {
        $('.error').hide();
        if (surname.length > 0) {

            $.ajax({
                url: "database/surname.php",
                type: "POST",
                data: 'surname=' + surname,
                success: (data) => {
                    $('.wrap').html(data);
                },
                error: () => {
                    $('.wrap').html('<p>Error al conectar con la BBDD, inténtelo de nuevo pasados unos minutos</p>');
                }
            });

        } else {
            $('.wrap').html('<p class="no-results">Sin resultados</p>');
        }
    }
});