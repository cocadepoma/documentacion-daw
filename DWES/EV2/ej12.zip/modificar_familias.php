<?php

include_once('./funciones.php');

/*----- ( Option 1 -> INSERT )  ( Option 3 -> DELETE )  ( Option 5 -> DELETE ) ------*/
if (isset($_GET['action']) && $_GET['action'] != null) {
    libreriaSweetAlert();
    if (ctype_digit($_GET['action']) && ($_GET['action'] == 1 || $_GET['action'] == 3 || $_GET['action'] == 5)) {

        $opcion = intval($_GET['action']);

        switch ($opcion) {
            case 1:

                # INSERT
                cabecera();
                formulario();
                pie();
                break;

            case 3:

                # UPDATE
                if (comprobarCodigoFamiliaGet()) {

                    $codigo_modificar = $_GET['familia'];

                    if (comprobarCodigoFamilia($codigo_modificar) && datosFamilia($codigo_modificar)) {

                        $datos = datosFamilia($codigo_modificar);
                        cabecera();
                        alertaSwalInfo('Familia encontrada, redigiriendo...');
                        formulario($datos['ccodigo'], $datos['cnombre'], $datos['mobservaciones'], 'editar');
                        pie();
                    } else {
                        alertaSwalError('No se han encontrado coincidencias');
                    }
                }
                break;

            case 5:

                # DELETE

                if (comprobarCodigoFamiliaGet()) {
                    $codigo_eliminar = $_GET['familia'];

                    if (comprobarCodigoFamilia($codigo_eliminar)) {
                        borrarFamilia($codigo_eliminar);
                    } else {
                        alertaSwalError('No se han encontrado coincidencias');
                    }
                }
                break;
        }
    } else {
        alertaSwalError('Ha habido un error en la página, inténtelo de nuevo más tarde', '', 'index.php');
    }
}

// Insertar en BBDD una familia NUEVA
if (isset($_POST['submit']) && $_POST['submit'] == 'guardar') {

    libreriaSweetAlert();
    if (comprobarLongitudStr($_POST['codigo'])) {

        $codigo_familia = strtoupper($_POST['codigo']);
        $nombre_familia = null;
        $observaciones = null;
        $encontrado = false;

        if (strlen($_POST['nombre']) > 0) {
            $nombre_familia = $_POST['nombre'];
        }
        if (strlen($_POST['observaciones']) > 0) {
            $observaciones = $_POST['observaciones'];
        }

        if (!comprobarCodigoFamilia($codigo_familia)) {

            $db = conectar();

            if ($db) {

                $query = "INSERT INTO familias (ccodigo, cnombre, mobservaciones) VALUES (?, ?, ?)";

                // Create Statement
                $stmt = $db->prepare($query);
                $stmt->bind_param("sss", $codigo_familia, $nombre_familia, $observaciones);

                // Execute Statement
                if ($stmt->execute()) {
                    $stmt->close();
                    desconectar($db);
                    alertaSwalSuccess('Familia creada correctamente, redigiriendo al listado...', 'modificar_familias.php?listar=1');
                } else {
                    $stmt->close();
                    desconectar($db);
                    alertaSwalError('Ha habido un error en la inserción, inténtelo más tarde');
                    //mensaje('Ha habido un error en la inserción, inténtelo más tarde', 'index.php');
                }
            }
        } else {
            alertaSwalError('Error, ese código ya existe', 'Puedes intentarlo con otro...');
        }
    } else {
        alertaSwalError('Debes especificar un código', 'Deben introducirse de 1 a 5 caracteres');
    }
}

// Modificar en BBDD una familia EXISTENTE
if (isset($_POST['submit']) && $_POST['submit'] == 'modificar') {

    $codigo_update = '';
    $nombre_update = null;
    $observaciones_update = null;

    if (isset($_POST['codigo']) && strlen($_POST['codigo']) > 0 && strlen($_POST['codigo']) <= 5) {
        $codigo_update = $_POST['codigo'];
    }
    if (isset($_POST['nombre'])) {
        $nombre_update = $_POST['nombre'];
    }
    if (isset($_POST['observaciones'])) {
        $observaciones_update = $_POST['observaciones'];
    }

    updateFamilia($nombre_update, $observaciones_update, $codigo_update);
}

// Eliminar en BBDD una familia EXISTENTE
if (isset($_POST['submit']) && $_POST['submit'] == 'cancelar') {

    libreriaSweetAlert();

    echo "<script language='javascript'> 
            document.addEventListener('DOMContentLoaded', ()=>{
                Swal.fire({
                    title: 'A qué página quieres ir?',
                    showDenyButton: true,
                    confirmButtonText: `Página principal`,
                    denyButtonText: `Listado de familias`,
                    allowOutsideClick: false
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        document.location.href='index.php';
                    } else if (result.isDenied) {
                        document.location.href='modificar_familias.php?listar=1';
                    }
                })
            });
        </script>";
}

// Listar TODAS las familias
if (isset($_GET['listar']) && $_GET['listar'] == 1) {
    listarFamilias();
}

// Comprueba si la longitud de un STRING es mayor que 0 y menor que 6
function comprobarLongitudStr($str)
{
    if (strlen($str) > 0 && strlen($str) < 6) {
        return true;
    } else {
        return false;
    }
}

// Comprueba si el código introducido por GET cumple con los requisitos n > 0 y n <= 5
function comprobarCodigoFamiliaGet()
{
    if (!isset($_GET['familia']) || $_GET['familia'] == null || strlen($_GET['familia']) == 0 || strlen($_GET['familia']) > 5) {
        libreriaSweetAlert();
        alertaSwalError('El código de familia no es válido', 'Deben introducirse de 1 a 5 caracteres');
    } else {
        return true;
    }
}

/*----------------# Imprimir formulario familia NUEVA y EXISTENTE #----------------*/
function formulario($codigo = 'Introducir código . . .', $nombre = 'Introducir nombre . . .', $observaciones = 'Observaciones importantes sobe la familia . . .', $opcion = 'nuevo')
{

    // NOMBRE FAMILIA
    if ($opcion == 'editar') {
        echo '<h2><span class="famiglia">Familia:</span> ' . $nombre . '</h2>';
    } else {
        echo '<h2>Nueva Familia</h2>';
    }

    echo '<form method="POST" action="modificar_familias.php">';

    // FUNCION
    if ($opcion == 'editar') {
        echo "<h4 class='center'>Editar Familia</h4>";
    } else {
        echo "<h3 class='center'>Crear Familia</h3>";
    }

    echo '<label for="codigo">Código:</label>';

    // CODIGO
    if ($opcion == 'editar') {
        echo '<input disabled class="dark" type="text" name="codigo" id="codigo" placeholder="Introducir código . . ." value="' . $codigo . '">';
        echo '<input type="hidden" name="codigo" value="' . $codigo . '">';
    } else {
        echo '<input type="text" name="codigo" id="codigo" placeholder="' . $codigo . '">';
    }

    echo '<br><br>';
    echo '<label for="nombre">Nombre:</label>';

    // NOMBRE
    if ($opcion == 'editar') {
        echo '<input type="text" name="nombre" id="nombre" placeholder="Introducir nombre . . ." value="' . $nombre . '">';
    } else {
        echo '<input type="text" name="nombre" id="nombre" placeholder="' . $nombre . '">';
    }

    echo '<br><br>';
    echo '<label for="observaciones">Observaciones:</label>';

    // TEXTAREA
    if ($opcion == 'editar') {
        echo '<textarea name="observaciones" id="observaciones" cols="30" rows="10" placeholder="Observaciones importantes sobe la familia . . .">' . $observaciones . '</textarea>';
    } else {
        echo '<textarea name="observaciones" id="observaciones" cols="30" rows="10" placeholder="' . $observaciones . '"></textarea>';
    }

    echo '<br><br>';
    echo '<div class="buttons">';

    // BOTONES
    if ($opcion == 'editar') {
        echo '<input class="btn btn-green" name="submit" type="submit" value="modificar">';
        echo '<input type="hidden" name="submit" value="modificar">';
    } else {
        echo '<input class="btn btn-green" name="submit" type="submit" value="guardar">';
        echo '<input type="hidden" name="submit" value="guardar">';
    }

    echo '<input class="btn btn-red" name="submit" type="submit" value="cancelar">';

    echo '</div>';
    echo '</form>';
}

////////////////// Imprimir cabecera tabla ////////////////////////
function cabeceraListado()
{
    echo "<div class='tabla'>";
    echo "<div class='row row-head'>";
    echo "<div class='codigo'>Codigo</div>";
    echo "<div class='nombre'>Nombre</div>";
    echo "<div class='obs'>Observaciones</div>";
    echo "<div class='nuevo'><a href='modificar_familias.php?action=1'>Nuevo</a></div>";
    echo "</div>";
}

##################################### ( MYSQL SELECTS ) #####################################

function listarFamilias()
{
    $db = conectar();

    if ($db) {

        $query = "SELECT * FROM familias";
        if ($resultado = $db->query($query)) {

            cabecera();
            cabeceraListado();

            while ($row = $resultado->fetch_assoc()) { ?>

                <div class="row">
                    <div class="codigo"><?php echo $row['ccodigo']; ?></div>
                    <div class="nombre"><?php echo $row['cnombre']; ?></div>
                    <div class="obs"><?php echo $row['mobservaciones']; ?></div>
                    <div class="nuevo">
                        <a class="editar" href="modificar_familias.php?action=3&familia=<?php echo $row['ccodigo']; ?>"><i class="far fa-edit"></i></a>
                        <a class="eliminar" href="modificar_familias.php?action=5&familia=<?php echo $row['ccodigo']; ?>"><i class="far fa-trash-alt"></i></a>
                    </div>
                </div>
<?php
            }
            echo "</div>";
            echo "<a class='a-center' href='index.php'>Home</a>";
            pie();
        }
    }
}

////////////// Comprobar mediante un código, si corresponde a alguna familia //////////////////////
function comprobarCodigoFamilia($codigo)
{
    $db = conectar();
    $encontrado = false;

    if ($db) {

        $query = "SELECT ccodigo FROM familias";

        if ($resultado = $db->query($query)) {

            while ($row = $resultado->fetch_assoc()) {
                if (strtoupper($codigo) == $row['ccodigo']) {
                    $encontrado = true;
                }
            }
        }
        desconectar($db);

        return $encontrado;
    } else {
        return $encontrado;
    }
}

////// Obtener datos de una familia por su código y devolver un ARRAY ///////
function datosFamilia($codigo)
{

    $datos_familia = null;
    $db = conectar();

    if ($db) {
        $query = "SELECT ccodigo, cnombre, mobservaciones FROM familias where ccodigo = ?";

        $stmt = $db->prepare($query);
        $stmt->bind_param('s', $codigo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                $datos_familia = $row;
            }
        }
        $stmt->close();
        desconectar($db);
    }
    if (count($datos_familia) > 0) {
        return $datos_familia;
    } else {
        return false;
    }
}

##################################### ( MYSQL UPDATES ) #####################################
function updateFamilia($nombre_update, $observaciones_update, $codigo_update)
{
    libreriaSweetAlert();
    $db = conectar();

    if ($db) {

        $query = "UPDATE familias SET cnombre = ?, mobservaciones = ? WHERE ccodigo = ?";

        $stmt = $db->prepare($query);
        $stmt->bind_param('sss', $nombre_update, $observaciones_update, $codigo_update);
        $status = $stmt->execute();

        if ($status) {
            $stmt->close();
            desconectar($db);
            libreriaSweetAlert();
            alertaSwalSuccess('Familia modificada correctamente!', 'modificar_familias.php?listar=1');
        } else {
            desconectar($db);
            alertaSwalError('Error al realizar la modificación, inténtelo de nuevo más tarde');
        }
    }
}

##################################### ( MYSQL DELETES ) #####################################
function borrarFamilia($codigo_eliminar)
{
    libreriaSweetAlert();

    $db = conectar();

    if ($db) {

        $query = "DELETE FROM familias WHERE ccodigo = ?";

        $stmt = $db->prepare($query);
        $stmt->bind_param('s', $codigo_eliminar);
        $status = $stmt->execute();

        if ($status) {
            $stmt->close();
            desconectar($db);
            alertaSwalSuccess('Familia borrada satisfactoriamente', 'modificar_familias.php?listar=1');
        } else {
            $stmt->close();
            desconectar($db);
            alertaSwalError('Error al borrar, inténtelo de nuevo más tarde', '', 'index.php');
        }
    }
}

##################### SWEET ALERT2 #####################
//********** Incluir libreria SweetAlert 2 **********//
function libreriaSweetAlert()
{
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>";
}
//********** Alerta SweetAlert2 ERROR **********//
function alertaSwalError($titulo, $texto = '', $url = '')
{
    if (strlen($url) > 0) {
        echo "<script language='javascript'> 
                document.addEventListener('DOMContentLoaded', ()=>{
                    Swal.fire({
                        position: 'center',
                        icon: 'error',
                        title: '" . $titulo . "',
                        text: '" . $texto . "',
                        showConfirmButton: true,
                        timer: 2500
                    }).then( ()=>{
                        document.location.href='" . $url . "';
                    });
                });
            </script>";
    } else {
        echo "<script language='javascript'> 
                document.addEventListener('DOMContentLoaded', ()=>{
                    Swal.fire({
                        position: 'center',
                        icon: 'error',
                        title: '" . $titulo . "',
                        text: '" . $texto . "',
                        showConfirmButton: true,
                        timer: 2500
                    }).then( ()=>{
                        document.location.href=document.referrer;
                    });
                });
            </script>";
    }
}
//********** Alerta SweetAlert2 SUCCESS **********//
function alertaSwalSuccess($titulo, $url, $texto = '')
{
    echo "<script language='javascript'> 
            document.addEventListener('DOMContentLoaded', ()=>{
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: '" . $titulo . " ',
                    text: '" . $texto . "',
                    showConfirmButton: false,
                    timer: 1200
                }).then( ()=>{
                    document.location.href='" . $url . "';
                });
            });
        </script>";
}
//********** Alerta SweetAlert2 INFO **********//
function alertaSwalInfo($titulo)
{
    echo "<script language='javascript'> 
            document.addEventListener('DOMContentLoaded', ()=>{
                Swal.fire({
                    position: 'center',
                    title: '" . $titulo . "',
                    showConfirmButton: false,
                    timer: 1000,
                    didOpen: () => {
                        swal.showLoading();
                    }
                })
            });
        </script>";
}
######################################################

?>