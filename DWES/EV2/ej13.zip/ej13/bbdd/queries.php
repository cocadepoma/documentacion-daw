<?php
######################### USERS #########################
// If user IS ADMIN, will return 1. ELSE will return 0
function getIfAdmin($usr_name)
{
    $admin = 0;

    try {

        $conn = connectDB();
        if ($conn) {

            $sql = "SELECT ntipo FROM usuarios WHERE cnombre = :usr_name";
            $stmt = $conn->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            $stmt->execute(array(':usr_name' => $usr_name));

            while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if ($result['ntipo'] === '1') {
                    $admin = 1;
                }
            }

            $stmt->closeCursor();
            disconectDB($conn);
        }
    } catch (Exception $e) {
        header("location: ../index.php?bderror=true&typeerror=" . $e->getMessage());
    }

    return $admin;
}
// List user profile info
function getUsrInfo($usr_name)
{
    try {
        $conn = connectDB();

        if ($conn) {
            $sql = "SELECT ncodigo, cnombre FROM usuarios WHERE cnombre = :usr_name";
            $stmt = $conn->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            $stmt->execute(array(':usr_name' => $usr_name));

            while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . $result['ncodigo'] . "</td>";
                echo "<td>" . $result['cnombre'] . "</td>";
                echo "</tr>";
            }
        }
    } catch (Exception $e) {
        header("location: ../index.php?bderror=true&typeerror=" . $e->getMessage());
    }
}
#########################################################

######################## CLIENTS ########################
// List full clients
function getAllClients()
{
    try {

        $conn = connectDB();
        if ($conn) {

            $sql = "SELECT ncodigo, ccif, cnombre, capellidos, cdireccion FROM clientes ORDER BY ncodigo ASC";
            $stmt = $conn->query($sql);

            while ($result = $stmt->fetch()) {
                echo "<tr>";
                echo "<td>" . $result['ncodigo'] . "</td>";
                echo "<td>" . $result['ccif'] . "</td>";
                echo "<td>" . $result['cnombre'] . "</td>";
                echo "<td>" . $result['capellidos'] . "</td>";
                echo "<td>" . $result['cdireccion'] . "</td>";
                echo "</tr>";
            }

            $stmt->closeCursor();
            disconectDB($conn);
        }
    } catch (Exception $e) {
        header("location: ../index.php?bderror=true&typeerror=" . $e->getMessage());
    }
}
// Delete client with the ID
function deleteClient($id)
{
    try {
        $conn = connectDB();
        if ($conn) {

            $sql = "DELETE FROM clientes WHERE ncodigo = :client_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':client_id', $id, PDO::PARAM_INT);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                header('location: ../index.php?deletion=true');
            } else {
                header('location: ../borrar.php?deletion=false');
            }
            $stmt->closeCursor();
            disconectDB($conn);
        } else {
            header("location: ../borrar.php?bderror=true");
        }
    } catch (Exception $e) {
        header("location: ../borrar.php?bderror=true&typeerror=" . $e->getMessage());
    }
}
// Check if a client ID is already registered
function checkIfClientExists($id)
{
    $exists = false;

    try {
        $conn = connectDB();
        if ($conn) {

            $sql = "SELECT ncodigo FROM clientes WHERE ncodigo = :client_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':client_id', $id, PDO::PARAM_INT);
            $stmt->execute();

            while ($result = $stmt->fetch()) {
                if ($result['ncodigo'] == $id) {
                    $exists = true;
                }
            }

            $stmt->closeCursor();
            disconectDB($conn);
        } else {
            header("location: ../altas.php?bderror=true");
        }
    } catch (Exception $e) {
        header("location: ../altas.php?bderror=true&typeerror=" . $e->getMessage());
    }
    return $exists;
}
// Insert a new client
function insertClientByID($client_ID = null, $client_CIF = '', $client_name = '', $client_surname = '', $client_phone = '', $client_address = '')
{
    try {
        $data = [
            ':client_id' => $client_ID,
            ':client_cif' => $client_CIF,
            ':client_name' => $client_name,
            ':client_surname' => $client_surname,
            ':client_phone' => $client_phone,
            ':client_address' => $client_address,
        ];

        $conn = connectDB();

        if ($conn) {

            $sql = "INSERT INTO clientes (ncodigo, ccif, cnombre, capellidos, ctelefono, cdireccion) 
                    VALUES (:client_id, :client_cif, :client_name, :client_surname, :client_phone, :client_address)";
            $stmt = $conn->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

            if ($stmt->execute($data)) {
                header("location: ../index.php?insert=true");
            } else {
                header("location: ../altas.php?insert=false");
            }
        } else {
            header("location: ../altas.php?bderror=true");
        }
    } catch (Exception $e) {
        header("location: ../altas.php?bderror=true&typeerror=" . $e->getMessage());
    }
}
#########################################################
