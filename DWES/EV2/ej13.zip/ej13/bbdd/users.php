<?php
session_start();
include_once('./connection.php');

$text_pattern = "/^[a-zA-ZáéíóúÁÉÍÓÚäëïöüÄËÏÖÜàèìòùÀÈÌÒÙ\s]+$/";

############################# CREATE USERS FORM #############################
// Check submit creation
if (isset($_POST['user-create'])) {
    // Check if inputs are in POST
    if (isset($_POST['name']) && isset($_POST['password']) && isset($_POST['type'])) {

        $name_err = true;
        $pwd_err = true;
        $type_err = true;

        // Check valid name length > 2
        if (!empty($_POST['name']) && strlen($_POST['name']) > 2) {
            if (ctype_alnum($_POST['name'])) {
                $name_err = false;
                $user_name = strtolower(htmlspecialchars($_POST['name']));
            }
        }
        // Check valid pwd length >= 4
        if (!empty($_POST['password']) && strlen($_POST['password']) >= 4) {
            $pwd_err = false;
            $user_pwd = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }
        //Check valid type
        if ($_POST['type'] == '0' || $_POST['type'] == '1') {
            $type_err = false;
            $user_type = $_POST['type'];
        }

        // If inputs are OK, continue
        if (!$name_err && !$pwd_err && !$type_err) {
            $conn = connectDB();
            if ($conn) {

                try {
                    $match = false;
                    $sql = "SELECT cnombre FROM usuarios";
                    $result = $conn->query($sql);

                    // Check if user already exists in DATABASE
                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                        if ($row['cnombre'] == $user_name) {
                            $match = true;
                        }
                    }

                    // If user doesn't exists, INSERT INTO
                    if (!$match) {

                        $sql = "INSERT INTO usuarios (cnombre, cpwd, ntipo) VALUES (:usr_name, :usr_pwd, :usr_type)";
                        $stmt = $conn->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));

                        if ($stmt->execute(array(':usr_name' => $user_name, ':usr_pwd' => $user_pwd, ':usr_type' => $user_type))) {
                            $stmt->closeCursor();
                            $conn = null;
                            header("location: ../new-users.php?creating=true");
                        } else {
                            $stmt->closeCursor();
                            $conn = null;
                            header("location: ../new-users.php?creating=false");
                        }
                    } else {
                        $conn = null;
                        header("location: ../new-users.php?userexist=true");
                    }
                } catch (Exception $e) {
                    $conn = null;
                    header("location: ../new-users.php?bderror=true&typeerror=" . $e->getMessage());
                }
                echo "ok";
            } else {
                header("location: ../new-users.php?bderror=true");
            }
        } else {
            header("location: ../new-users.php?emptyparams=true");
        }
    } else {
        header("location: ../new-users.php?emptyparams=true");
    }
}
#############################################################################

################################# LOGIN FORM ################################
// Check submit login
if (isset($_POST['login'])) {
    // Check if inputs are in POST
    if (isset($_POST['username']) && isset($_POST['password'])) {

        // Check if inputs are valid
        if (!empty($_POST['username']) && !empty($_POST['password']) && strlen($_POST['username']) > 0 && strlen($_POST['password']) > 0) {

            $login_user_name = strtolower($_POST['username']);
            $login_usr_pwd = $_POST['password'];
            $usr_match = false;

            try {
                $conn = connectDB();
                if ($conn) {
                    $sql = "SELECT cnombre, cpwd FROM usuarios where cnombre = :usr_name";
                    $stmt = $conn->prepare($sql, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
                    $stmt->execute(array(':usr_name' => $login_user_name));

                    while ($result = $stmt->fetch(PDO::FETCH_ASSOC)) {

                        if ($login_user_name == $result['cnombre']) {
                            echo "nombre pillado";
                            if (password_verify($login_usr_pwd, $result['cpwd'])) {
                                $usr_match = true;
                            }
                        }
                    }

                    $stmt->closeCursor();
                    disconectDB($conn);

                    // If user exists, create session a redirect to index.php
                    if ($usr_match) {
                        $_SESSION['user'] = $login_user_name;
                        header('location: ../index.php');
                    } else {
                        header('location: ../login.php?login=false');
                    }
                } else {
                    header("location: ../login.php?bderror=true");
                }
            } catch (Exception $e) {
                header("location: ../login.php?bderror=true&typeerror=" . $e->getMessage());
            }
        } else {
            var_dump($_POST);
            header("location: ../login.php?emptyparams=true");
        }
    }
}
#############################################################################

############################## SESSION DESTROY ##############################
if (isset($_POST['close']) && isset($_SESSION['user'])) {
    session_destroy();
    header('location: ../login.php');
}
#############################################################################
