<?php
include('./templates/errors/db-access-error.php');

include('./templates/layout/header.php');

include('./templates/layout/signup-form.php');

include('./templates/layout/footer.php');
