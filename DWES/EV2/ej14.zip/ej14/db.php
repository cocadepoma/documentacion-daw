<?php

class Conexion
{
    public $conn; //PDO

    private $dbtype; //string
    private $url; //string
    private $dbname; //string
    private $usr; //string
    private $pwd; //string

    public function __construct()
    {
        $string_json = file_get_contents("./config.json");
        $json = json_decode($string_json, true);

        foreach ($json as $key => $value) {

            switch ($key) {
                case 'bbdd':
                    $this->dbtype = $value;
                    break;
                case 'ruta':
                    $this->url = $value;
                    break;
                case 'dbname':
                    $this->dbname = $value;
                    break;
                case 'usr':
                    $this->usr = $value;
                    break;
                case 'pwd':
                    $this->pwd = $value;
                    break;
            }
        }
    }

    public function getConector()
    {
        $options = [
            PDO::ATTR_EMULATE_PREPARES   => false, // turn off emulation mode for "real" prepared statements
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, //turn on errors in the form of exceptions
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, //make the default fetch be an associative array
        ];

        try {
            $this->conn = new PDO("$this->dbtype:host=$this->url; dbname=$this->dbname; charset=utf8", "$this->usr", "$this->pwd", $options);

            if ($this->conn) {
                return $this->conn;
            } else {
                return 0;
            }
        } catch (Exception $e) {
            error_log($e->getMessage());
            exit('Something weird happened');
        }
    }

    public function cerrar()
    {
        $this->conn = null;
    }
}
