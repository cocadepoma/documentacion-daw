<?php require_once('./db.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ej14</title>
    <style>
        table {
            background-color: burlywood;
            border-collapse: collapse;
            margin: 100px auto 0 auto;
            border-radius: 5px;
            -webkit-box-shadow: 6px 4px 22px 0px rgba(0, 0, 0, 0.75);
            -moz-box-shadow: 6px 4px 22px 0px rgba(0, 0, 0, 0.75);
            box-shadow: 6px 4px 22px 0px rgba(0, 0, 0, 0.75);
        }

        table td {
            border: 1px solid black;
            padding: 5px;
        }

        .thead {
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <table>
        <tr class='thead'>
            <td>CIF</td>
            <td>NOMBRE</td>
            <td>APELLIDOS</td>
            <td>DIRECCION</td>
        </tr>

        <?php
        $conexion = new Conexion();
        $conn = $conexion->getConector();

        try {

            if ($conn) {

                $sql = "SELECT ccif, cnombre, capellidos, cdireccion FROM clientes ORDER BY capellidos ASC";
                $stmt = $conn->prepare($sql);
                $stmt->execute();

                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . $row['ccif'] . "</td>";
                    echo "<td>" . $row['cnombre'] . "</td>";
                    echo "<td>" . $row['capellidos'] . "</td>";
                    echo "<td>" . $row['cdireccion'] . "</td>";
                    echo "</tr>";
                }
                $stmt->closeCursor();
                $conexion->cerrar();
            } else {
                echo "Connection error";
            }
        } catch (Exception $e) {
            echo "<p>An error happenede, try it again later</p>";
            echo "<p>" . $e->getMessage() . "</p>";
        }

        ?>
    </table>
</body>

</html>