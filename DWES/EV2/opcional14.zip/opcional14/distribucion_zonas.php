<?php
    require_once('./database/connection.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <?php include_once('./service/tarta.php'); ?>
</head>
<body>
    
     <div id="piechart" style="width: 900px; height: 500px;"></div>
     <a href="index.php">Volver atrás</a>      
</body>
</html>