<?php
    require_once('./database/connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lindavista</title>
    <style>
        h1 {
            text-align: center;
        }
        thead {
            background-color: lightblue;
            font-weight: bold;
        }
        td {
            padding: 5px;
            border: 1px solid black;
        }
        table {
            margin: 0 auto;
            border-collapse: collapse;
            max-width: 1200px;
        }
        table img {
            max-width: 100%;
        }
        .casas {
            margin-top: 20px;
            display: block;
            text-align: center;
            text-decoration: none;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: red;
        }
    </style>
</head>
<body>

    <h1>Lindavista</h1>

    <?php 
    
    if($mysqli->connect_errno) {
        echo "Fallo al conectar: " . $mysqli->connect_error;
    } else {
        $query = "SELECT * FROM viviendas";
        
        if($resultado = $mysqli->query($query)) {

            echo "<table><thead><tr><td>ID</td><td>Tipo</td><td>Zona</td><td>Dirección</td><td>Dormitorios</td><td>Precio</td><td>Tamaño</td><td>Extras</td><td>Fotos</td><td>Observaciones</td></tr></thead><tbody>";
            
            while($fila = $resultado->fetch_assoc()){
                echo "<tr><td>" . $fila['id'] . "</td><td>" . $fila['tipo'] . "</td><td>"  . $fila['zona'] . "</td><td>" . $fila['direccion'] . "</td><td>" . $fila['ndormitorios'] . "</td><td>" . $fila['precio'] . "</td><td>". $fila['tamano'] ."</td><td>" . $fila['extras'] . "</td><td>" ?> <img src="<?php echo $fila['foto'];?>" alt="fotocasa"> <?php echo "</td><td>" . $fila['observaciones'] . "</td></tr>";
            }

            echo "</tbody></table>";
        }
        
        $mysqli->close();

        echo "<a class='casas' href='distribucion_zonas.php'>Gráfica distribución por zonas</a>";
    }
    
    
    ?>
</body>
</html>