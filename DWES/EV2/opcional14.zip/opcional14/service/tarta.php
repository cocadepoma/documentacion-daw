<?php
    if($mysqli->connect_errno) {
        echo "Fallo al conectar con la base de datos: ";

    } else { ?>
        <script type="text/javascript">
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {

                var data = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],
                <?php
                    $query = "SELECT zona, count(*) FROM viviendas GROUP BY zona";
                    if($resultado = $mysqli->query($query)) {
                        while($fila = $resultado->fetch_assoc()){
                            echo "['". $fila['zona']. "',". $fila['count(*)'] . "],";
                        }
                    }
                    $mysqli->close();
                ?>

                ]);

                var options = {
                    title: 'Clasificación por barrios',
                    is3D: true,

                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                chart.draw(data, options);
            }
        </script>  
<?php } ?>