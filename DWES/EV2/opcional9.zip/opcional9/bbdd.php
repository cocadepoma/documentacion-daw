<?php

    $mysqli = new mysqli("localhost", "cursophp", "1234", "lindavista");
    $mysqli->set_charset("utf8");
?>